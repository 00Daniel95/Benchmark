<?php
// Begin AIOWPSEC Firewall
if (file_exists('/Applications/XAMPP/xamppfiles/htdocs/wineblog/aios-bootstrap.php')) {
	include_once('/Applications/XAMPP/xamppfiles/htdocs/wineblog/aios-bootstrap.php');
}
// End AIOWPSEC Firewall
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'wineblog' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'hnJM_4vO38P!thFeFoja.:HkHd4jwy?zbO0nS}pT(=22{QwTl0bi2fax3O+F,J5F' );
define( 'SECURE_AUTH_KEY',  '5113zAL9yWK(??WF5,m _7|[.H?a6&C{}`T3WZ+il6;P0{LyJcWo^sh^}C`Q6Nld' );
define( 'LOGGED_IN_KEY',    '-pK?9,Iq<IkDlG38D-MD^:CJ6_9P*P4=v]eUfK*_vI^%8+i~*pl6X[VKd;$cNQr#' );
define( 'NONCE_KEY',        '6a!_62o9k%2n<`#*,+:RW{^1Gfg6arMd7!j`_~TcU/M5^qItpL>|;E]k)<LLuu0*' );
define( 'AUTH_SALT',        ':%jv$e+KL-fiZn:)Vn4=jb&jDY0AtH]ZXdPG_cFZ&,c3(<$$MmhH2g[N0`hj$U 0' );
define( 'SECURE_AUTH_SALT', 'J7*kpJt=A!1E[J)_f]Xfs1t){k1kTPZ;@(Cdz3NR!WB&gI#6b_HJ2wr48T*SLz+l' );
define( 'LOGGED_IN_SALT',   ' y6e}*chT%R`;~#V-O=m.ias}=+H7A&<^9>Lm3oD?o>~tk8ybK86(<xq-Phrb1|R' );
define( 'NONCE_SALT',       'QTjD;q4.%YJsr=jzUBlmD|QLv8ihpEBL5*A,* |cs=s{*Z!pBSZP[.lw0!NK1KH%' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'wp_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';
define('FS_METHOD', 'direct');

@ini_set( 'upload_max_filesize' , '128M' );
@ini_set( 'post_max_size', '128M');
@ini_set( 'memory_limit', '256M' );
@ini_set( 'max_execution_time', '300' );
@ini_set( 'max_input_time', '300' );